// import React from 'react';
import './Login.css';
import jbplogo from './jbplogo.png';
import Admin from './Admin.jpg';
import React, { useState } from 'react';
 // Import the CSS file for styling

const Adminlogin = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);




  const handleUsernameChange = (e) => {
    setUsername(e.target.value);
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  const handleShowPasswordToggle = () => {
    setShowPassword(!showPassword);
  };

  const handleLogin = (e) => {
    e.preventDefault();
    // Handle login logic here
  };

  const handleRegister = () => {
    // Handle registration logic here
  };
    return(
       
  <div>
       <nav className="navbar">
      <div id="logo" className="logo">
        <img src={jbplogo} alt="Logo" />
      </div>
      {/* <div className='title'> <span>Admin Login</span></div> */}
      <div className="links">
       
        <h3> </h3>
        <h3> </h3>
        
       
      </div>
    </nav>
    <div className='title'> 
    <span>Admin Login</span>
    </div>
    <div className="maincontainer">
      <div className="left-container">
      <div id="container-img" className="container-img">
      <img src={Admin} alt="Image"/>
    </div>
      </div>
      <div className="right-container">
      <div className="container-login">
      <form id="login-from" className="login-form" onSubmit={handleLogin}>
        <h2>Login</h2>
        <div className="form-group">
          <label htmlFor="username">User Id</label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={handleUsernameChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password</label>
          <div className="password-input">
            <input
              type={showPassword ? 'text' : 'password'}
              id="password"
              value={password}
              onChange={handlePasswordChange}
              required
            />
            <button
              type="button"
              className="show-password"
              onClick={handleShowPasswordToggle}
            >
              {showPassword ? 'Hide' : 'Show'}
            </button>
          </div>
        </div>
        <div className="form-group">
          <span className="forgot-password-button">
            <a href="#">Forgot Password</a>
          </span>
        </div>
        <div className="form-group">
          <button type="submit" className="login-button">
            Login
          </button>
        </div>
        <div className="form-group">
          <span>Don't have  an Account ?    </span><span
            
            className="register-button"
            onClick={handleRegister}>
          
           <a href="#"> Register</a>

          </span>
        </div>
       
      </form>
    </div>
      </div>
    </div>
        </div>
    )
}
export default Adminlogin;