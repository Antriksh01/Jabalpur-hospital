import React from 'react'
import pic from './jbplogo.png';

import './ForgetPasswordPage.css'
function ForgetPassword() {
  return (
    <> 
    <div className="header">
        <img id="img1" src={pic} />
        <h1 id="adm1">Forget Password Page</h1>
        <h3 id="hd">
          Hi, Admin Name <br />
          Employee Id
        </h3>
        <button className="btn1">Logout</button>
      </div>
      
      <div className="form">
     
        <input type="text" placeholder="Moblie No" style={{ border: "none" }} />
        <br />
        <br />
        
       
        <button type="button" className="btn">Send OTP</button>
      </div>
      </>
  )
}

export default ForgetPassword