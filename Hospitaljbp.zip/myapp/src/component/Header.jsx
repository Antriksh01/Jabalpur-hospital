import React from "react";
import './Header.css';
import Receptionist from "./Receptionist";
import jbplogo from './jbplogo.png';
import Doctor from "./Doctor";
import Dashboard from "./RDashboard";
import Doctordashboard from "./Doctordashboard";
import Admindashboard from "./Admindashboard";
import Token from "./TokenGeneration";
import Managedoctor from "./Managedoctor";
import Addadocter from "./Addadoctor";
import { Link } from "react-router-dom";
// import { Link, NavLink  } from "react-router-dom";

const Header =() => {
    return(
      

        <div>
         
        <nav className="navbar">
        <div id="logo" className="logo">
          <img src={jbplogo} alt="Logo" />
        </div>
        {/* <div className='title'> <span> </span></div> */}
        <div id="links" className="links">
         
          <h3>Hi Admin Name </h3>
          <h3>Employee Id</h3>
          <span Id="btu">
          <Link to= "/Frontpage" > <button >Logout</button></Link>
          <Link to= "/Frontpage" ><button>Go to Home</button></Link></span>
         
        </div>
      </nav>
      {/* <Receptionist/>
      <Doctor/>
      <Dashboard/>
      <Doctordashboard/>
      <Admindashboard/> */}

      </div>
      
    );
}
{/* <link to='./Doctor'></link> */}
export default Header;