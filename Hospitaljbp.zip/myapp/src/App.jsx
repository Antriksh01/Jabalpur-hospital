
import './App.css';
import Header from './component/Header';
import Frontpage from './component/Frontpage';
import Login from './component/Login';
import Doctorlogin from './component/Doctorlogin';
import Adminlogin from './component/Adminlogin';
import RDashboard from './component/RDashboard';
import Doctor from './component/Doctor';
//  import hamburger from  './component/Hamburger';
import Receptionist from './component/Receptionist';
import Managedoctor from './component/Managedoctor';
import Doctordashboard from './component/Doctordashboard';
import Admindashboard from './component/Admindashboard';
import Token from './component/TokenGeneration';
// import Addadocter from './component/Addadoctor';
 import Patientregistration from './component/Patientregistration';
 import Tokengenerated from './component/Tokengenerated'
 import DoctorTreatment from './component/DoctorTreatment';
 import TokenGeneration from './component/TokenGeneration';
 

//  import Doctortreatment from './component/Doctortreatment';

import { BrowserRouter, Route, Routes } from 'react-router-dom';
 import Patientopd from './component/patientopd';



function App() {
  return (
   
 <BrowserRouter>
 <Routes>
 <Route path='/' element={<Frontpage/>}/>
<Route path='/' element={<RDashboard/>}/>

{/* <Route path='/Doctor' element={<Doctor/>}/>
<Route path='./Patientopd' element={<Patientopd/>}/>
<Route path='/./Patientregistration' element={<Patientregistration/>}/>
<Route path='/DoctorTreatment' element= {<DoctorTreatment/>}/>
<Route path='/TokenGeneration' elemrnt={<TokenGeneration/>}/> */}


<Route path='/Adminlogin' elemrnt={<Adminlogin/>}/>
<Route path='/Doctorlogin' elemrnt={<Doctorlogin/>}/>
<Route path='/Login' elemrnt={<Login/>}/>


 </Routes>

 </BrowserRouter>


  


   
 
 

 );
}

export default App;
