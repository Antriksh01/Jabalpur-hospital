import React from 'react'


import './otp.css';
function OTP() {
  return (
    <> 
      <div className="heading">
        <h1 id='hd'>OTP PAGE</h1>
            
      <div className="form">
     
     <input type="text" placeholder="OTP" />
     <br />
     <br />
     
    
     <button type="button" className="btn">Sumbit</button>
   </div>

      </div>
  </>
  )
}

export default OTP;