export const ROLE_ADMIN = "admin";
export const ROLE_USER = "user";
export const ROLE_GUEST = "guest";
